﻿namespace PracWork38
{
    public partial class MainPage : ContentPage
    {
        private int _currentPage = 1;
        private int _pageSize = 5;
        private int _pagesCount = 1;
        private readonly string _directoryPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        private IEnumerable<FileInfo> _allFiles = Enumerable.Empty<FileInfo>();

        public MainPage()
        {
            InitializeComponent();
            LoadFiles();
            // Инициализация пикера размера страницы
            PageSizePicker.SelectedItem = "5";
            UpdateNavigationState();
        }

        private void LoadFiles()
        {
            try
            {
                var directory = new DirectoryInfo(_directoryPath);
                _allFiles = directory.GetFiles().AsEnumerable();
                UpdateFileList();
            }
            catch (Exception ex)
            {
                DisplayAlert("Ошибка", $"Не удалось загрузить файлы: {ex.Message}", "OK");
            }
        }

        private void UpdateFileList()
        {
            var filtered = _allFiles.AsEnumerable();

            // Применяем все фильтры
            filtered = FilterByName(filtered);
            filtered = FilterBySizeRadio(filtered);
            filtered = FilterBySizeRange(filtered);
            filtered = FilterByModifiedDate(filtered);
            filtered = FilterByCreatedDate(filtered);

            // Вычисляем количество страниц
            int totalItems = filtered.Count();
            _pagesCount = totalItems > 0 ? (int)Math.Ceiling(totalItems / (double)_pageSize) : 1;

            // Корректируем текущую страницу
            if (_currentPage > _pagesCount) _currentPage = _pagesCount;
            if (_currentPage < 1) _currentPage = 1;

            // Пагинация
            var result = filtered
                .Skip((_currentPage - 1) * _pageSize)
                .Take(_pageSize)
                .ToList();

            FilesListView.ItemsSource = result;
            CounterLabel.Text = $"Страница {_currentPage} из {_pagesCount} | Файлов: {result.Count} из {totalItems}";

            UpdateNavigationState();
        }

        // 3.1 Фильтр по имени
        private IEnumerable<FileInfo> FilterByName(IEnumerable<FileInfo> files)
        {
            if (!string.IsNullOrWhiteSpace(NameFilterEntry.Text))
                return files.Where(f => f.Name.Contains(NameFilterEntry.Text, StringComparison.OrdinalIgnoreCase));
            return files;
        }

        // 3.2 Фильтр по размеру (радиокнопки)
        private IEnumerable<FileInfo> FilterBySizeRadio(IEnumerable<FileInfo> files)
        {
            if (!long.TryParse(SizeFilterEntry.Text, out long sizeFilter))
                return files;

            // Исправлено: правильная проверка RadioButton
            if (GreaterOrEqualRadio.IsChecked)
                return files.Where(f => f.Length >= sizeFilter);

            if (LessOrEqualRadio.IsChecked)
                return files.Where(f => f.Length <= sizeFilter);

            return files;
        }

        // 3.3 Фильтр по диапазону размеров
        private IEnumerable<FileInfo> FilterBySizeRange(IEnumerable<FileInfo> files)
        {
            // Исправлено: правильная проверка CheckBox
            if (MinSizeCheck.IsChecked && long.TryParse(MinSizeEntry.Text, out long min))
                files = files.Where(f => f.Length >= min);

            if (MaxSizeCheck.IsChecked && long.TryParse(MaxSizeEntry.Text, out long max))
                files = files.Where(f => f.Length <= max);

            return files;
        }

        // 3.4 Фильтр по дате изменения
        private IEnumerable<FileInfo> FilterByModifiedDate(IEnumerable<FileInfo> files)
        {
            // Исправлено: правильная проверка CheckBox
            if (DateCheckBox.IsChecked && DatePickerFilter.Date != DateTime.MinValue)
                return files.Where(f => f.LastWriteTime.Date >= DatePickerFilter.Date);
            return files;
        }

        // 3.5 Фильтр по дате создания
        private IEnumerable<FileInfo> FilterByCreatedDate(IEnumerable<FileInfo> files)
        {
            if (DatePeriodPicker.SelectedIndex <= 0)
                return files;

            DateTime now = DateTime.Now;
            DateTime startDate = DatePeriodPicker.SelectedItem switch
            {
                "Сегодня" => now.Date,
                "За неделю" => now.AddDays(-7).Date,
                "В этом месяце" => new DateTime(now.Year, now.Month, 1),
                _ => DateTime.MinValue
            };

            return files.Where(f => f.CreationTime.Date >= startDate);
        }

        // Навигация по страницам
        private void OnFirstPageClicked(object sender, EventArgs e)
        {
            _currentPage = 1;
            UpdateFileList();
        }

        private void OnPrevPageClicked(object sender, EventArgs e)
        {
            if (_currentPage > 1) _currentPage--;
            UpdateFileList();
        }

        private void OnNextPageClicked(object sender, EventArgs e)
        {
            if (_currentPage < _pagesCount) _currentPage++;
            UpdateFileList();
        }

        private void OnLastPageClicked(object sender, EventArgs e)
        {
            _currentPage = _pagesCount;
            UpdateFileList();
        }

        // Переход по номеру страницы
        private void OnPageEntryCompleted(object sender, EventArgs e)
        {
            if (int.TryParse(PageEntry.Text, out int page) && page >= 1 && page <= _pagesCount)
            {
                _currentPage = page;
                UpdateFileList();
            }
        }

        // Изменение размера страницы
        private void OnPageSizeChanged(object sender, EventArgs e)
        {
            if (PageSizePicker.SelectedItem != null &&
                int.TryParse(PageSizePicker.SelectedItem.ToString(), out int newSize))
            {
                _pageSize = newSize;
                _currentPage = 1;
                UpdateFileList();
            }
        }

        // Блокировка кнопок навигации
        private void UpdateNavigationState()
        {
            FirstPageBtn.IsEnabled = PrevPageBtn.IsEnabled = (_currentPage > 1);
            NextPageBtn.IsEnabled = LastPageBtn.IsEnabled = (_currentPage < _pagesCount);
            PageEntry.Text = _currentPage.ToString();
            TotalPagesLabel.Text = _pagesCount.ToString();
        }

        // Обработчики событий
        private void OnFilterChanged(object sender, EventArgs e)
        {
            _currentPage = 1;
            UpdateFileList();
        }

        private void OnResetFilterClicked(object sender, EventArgs e)
        {
            NameFilterEntry.Text = string.Empty;
            UpdateFileList();
        }
    }
}
