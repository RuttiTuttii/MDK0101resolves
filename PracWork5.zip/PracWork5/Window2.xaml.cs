﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PracWork5
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
            string Login = Properties.Settings.Default.Login;
            string Password = Properties.Settings.Default.Password;
            string Email = Properties.Settings.Default.Email;
            LoginBox.Text = Login;
            PasswordBox.Text = Password;
            EmailBox.Text = Email;  
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.Login = LoginBox.Text;
            Properties.Settings.Default.Password = PasswordBox.Text;
            Properties.Settings.Default.Email = EmailBox.Text;
            Properties.Settings.Default.Save();

            OutputLabel.Content = "Success";
        }
    }
}
