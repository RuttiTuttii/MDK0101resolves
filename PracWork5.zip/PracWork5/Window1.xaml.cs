﻿using System.Windows;
using System.Configuration;

namespace PracWork5
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    /// 
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        string Login = Properties.Settings.Default.Login;
        string Password = Properties.Settings.Default.Password;
        string Email = Properties.Settings.Default.Email;

        private void AuthButton_Click(object sender, RoutedEventArgs e)
        {

            if (LoginBox.Text == Login && PasswordBox.Password == Password && EmailBox.Text == Email)
            {
                Hide();
                var window = new Window2();
                window.Show();
            }
            else
            {
                ErrorOutputLabel.Content = "Incorrect Data";
            }
        }
    }
}
